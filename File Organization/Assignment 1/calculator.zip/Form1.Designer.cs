﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.plus = new System.Windows.Forms.Button();
            this.number_0 = new System.Windows.Forms.Button();
            this.dot = new System.Windows.Forms.Button();
            this.equal = new System.Windows.Forms.Button();
            this.number_3 = new System.Windows.Forms.Button();
            this.number_2 = new System.Windows.Forms.Button();
            this.number_1 = new System.Windows.Forms.Button();
            this.min = new System.Windows.Forms.Button();
            this.number_6 = new System.Windows.Forms.Button();
            this.number_5 = new System.Windows.Forms.Button();
            this.number_4 = new System.Windows.Forms.Button();
            this.mul = new System.Windows.Forms.Button();
            this.number_9 = new System.Windows.Forms.Button();
            this.number_8 = new System.Windows.Forms.Button();
            this.number_7 = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.mud = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(332, 312);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(88, 47);
            this.plus.TabIndex = 0;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // number_0
            // 
            this.number_0.Location = new System.Drawing.Point(50, 365);
            this.number_0.Name = "number_0";
            this.number_0.Size = new System.Drawing.Size(88, 47);
            this.number_0.TabIndex = 19;
            this.number_0.Text = "0";
            this.number_0.UseVisualStyleBackColor = true;
            // 
            // dot
            // 
            this.dot.Location = new System.Drawing.Point(144, 365);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(88, 47);
            this.dot.TabIndex = 20;
            this.dot.Text = ".";
            this.dot.UseVisualStyleBackColor = true;
            // 
            // equal
            // 
            this.equal.BackColor = System.Drawing.Color.CornflowerBlue;
            this.equal.Location = new System.Drawing.Point(238, 365);
            this.equal.Name = "equal";
            this.equal.Size = new System.Drawing.Size(182, 47);
            this.equal.TabIndex = 21;
            this.equal.Text = "=";
            this.equal.UseVisualStyleBackColor = false;
            this.equal.Click += new System.EventHandler(this.equal_Click);
            // 
            // number_3
            // 
            this.number_3.Location = new System.Drawing.Point(238, 312);
            this.number_3.Name = "number_3";
            this.number_3.Size = new System.Drawing.Size(88, 47);
            this.number_3.TabIndex = 26;
            this.number_3.Text = "3";
            this.number_3.UseVisualStyleBackColor = true;
            // 
            // number_2
            // 
            this.number_2.Location = new System.Drawing.Point(144, 312);
            this.number_2.Name = "number_2";
            this.number_2.Size = new System.Drawing.Size(88, 47);
            this.number_2.TabIndex = 25;
            this.number_2.Text = "2";
            this.number_2.UseVisualStyleBackColor = true;
            // 
            // number_1
            // 
            this.number_1.Location = new System.Drawing.Point(50, 312);
            this.number_1.Name = "number_1";
            this.number_1.Size = new System.Drawing.Size(88, 47);
            this.number_1.TabIndex = 24;
            this.number_1.Text = "1";
            this.number_1.UseVisualStyleBackColor = true;
            // 
            // min
            // 
            this.min.Location = new System.Drawing.Point(332, 259);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(88, 47);
            this.min.TabIndex = 22;
            this.min.Text = "-";
            this.min.UseVisualStyleBackColor = true;
            this.min.Click += new System.EventHandler(this.min_Click);
            // 
            // number_6
            // 
            this.number_6.Location = new System.Drawing.Point(238, 259);
            this.number_6.Name = "number_6";
            this.number_6.Size = new System.Drawing.Size(88, 47);
            this.number_6.TabIndex = 31;
            this.number_6.Text = "6";
            this.number_6.UseVisualStyleBackColor = true;
            // 
            // number_5
            // 
            this.number_5.Location = new System.Drawing.Point(144, 259);
            this.number_5.Name = "number_5";
            this.number_5.Size = new System.Drawing.Size(88, 47);
            this.number_5.TabIndex = 30;
            this.number_5.Text = "5";
            this.number_5.UseVisualStyleBackColor = true;
            // 
            // number_4
            // 
            this.number_4.Location = new System.Drawing.Point(50, 259);
            this.number_4.Name = "number_4";
            this.number_4.Size = new System.Drawing.Size(88, 47);
            this.number_4.TabIndex = 29;
            this.number_4.Text = "4";
            this.number_4.UseVisualStyleBackColor = true;
            // 
            // mul
            // 
            this.mul.Location = new System.Drawing.Point(332, 206);
            this.mul.Name = "mul";
            this.mul.Size = new System.Drawing.Size(88, 47);
            this.mul.TabIndex = 27;
            this.mul.Text = "*";
            this.mul.UseVisualStyleBackColor = true;
            this.mul.Click += new System.EventHandler(this.mul_Click);
            // 
            // number_9
            // 
            this.number_9.Location = new System.Drawing.Point(238, 206);
            this.number_9.Name = "number_9";
            this.number_9.Size = new System.Drawing.Size(88, 47);
            this.number_9.TabIndex = 36;
            this.number_9.Text = "9";
            this.number_9.UseVisualStyleBackColor = true;
            // 
            // number_8
            // 
            this.number_8.Location = new System.Drawing.Point(144, 206);
            this.number_8.Name = "number_8";
            this.number_8.Size = new System.Drawing.Size(88, 47);
            this.number_8.TabIndex = 35;
            this.number_8.Text = "8";
            this.number_8.UseVisualStyleBackColor = true;
            // 
            // number_7
            // 
            this.number_7.Location = new System.Drawing.Point(50, 206);
            this.number_7.Name = "number_7";
            this.number_7.Size = new System.Drawing.Size(88, 47);
            this.number_7.TabIndex = 34;
            this.number_7.Text = "7";
            this.number_7.UseVisualStyleBackColor = true;
            // 
            // div
            // 
            this.div.Location = new System.Drawing.Point(332, 153);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(88, 47);
            this.div.TabIndex = 32;
            this.div.Text = "/";
            this.div.UseVisualStyleBackColor = true;
            // 
            // mud
            // 
            this.mud.Location = new System.Drawing.Point(50, 153);
            this.mud.Name = "mud";
            this.mud.Size = new System.Drawing.Size(88, 47);
            this.mud.TabIndex = 41;
            this.mud.Text = "%";
            this.mud.UseVisualStyleBackColor = true;
            this.mud.Click += new System.EventHandler(this.mud_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(144, 153);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(182, 47);
            this.clear.TabIndex = 37;
            this.clear.Text = "AC";
            this.clear.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(50, 27);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(370, 96);
            this.richTextBox1.TabIndex = 47;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 474);
            this.ControlBox = false;
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.mud);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.number_9);
            this.Controls.Add(this.number_8);
            this.Controls.Add(this.number_7);
            this.Controls.Add(this.div);
            this.Controls.Add(this.number_6);
            this.Controls.Add(this.number_5);
            this.Controls.Add(this.number_4);
            this.Controls.Add(this.mul);
            this.Controls.Add(this.number_3);
            this.Controls.Add(this.number_2);
            this.Controls.Add(this.number_1);
            this.Controls.Add(this.min);
            this.Controls.Add(this.equal);
            this.Controls.Add(this.dot);
            this.Controls.Add(this.number_0);
            this.Controls.Add(this.plus);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button number_0;
        private System.Windows.Forms.Button dot;
        private System.Windows.Forms.Button equal;
        private System.Windows.Forms.Button number_3;
        private System.Windows.Forms.Button number_2;
        private System.Windows.Forms.Button number_1;
        private System.Windows.Forms.Button min;
        private System.Windows.Forms.Button number_6;
        private System.Windows.Forms.Button number_5;
        private System.Windows.Forms.Button number_4;
        private System.Windows.Forms.Button mul;
        private System.Windows.Forms.Button number_9;
        private System.Windows.Forms.Button number_8;
        private System.Windows.Forms.Button number_7;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.Button mud;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

